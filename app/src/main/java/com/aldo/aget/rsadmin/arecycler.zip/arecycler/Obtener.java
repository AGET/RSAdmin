package com.aldo.aget.rsadmin.arecycler;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;


import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;
import android.widget.AdapterView.OnItemClickListener;

import com.aldo.aget.rsadmin.Configuracion.Configuracion;
import com.aldo.aget.rsadmin.Control.ManipulacionDatos;
import com.aldo.aget.rsadmin.R;


public class Obtener extends AppCompatActivity implements OnItemClickListener {
    EditText etResponse;
    TextView tvIsConnected;
    ArrayList datos;

    ManipulacionDatos datosLista;

    ListView lista;
    ArrayAdapter adaptador;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_obtener);

        // get reference to the views
        etResponse = (EditText) findViewById(R.id.etResponse);
        tvIsConnected = (TextView) findViewById(R.id.tvIsConnected);

        datosLista =  new ManipulacionDatos();

//        Lista

        //Instancia del ListView
        lista = (ListView)findViewById(R.id.lista);
//        Lista


        // check if you are connected or not
        if (isConnected()) {
            tvIsConnected.setBackgroundColor(0xFF00CC00);
            tvIsConnected.setText("You are conncted");
        } else {
            tvIsConnected.setText("You are NOT conncted");
        }


        // call AsynTask to perform network operation on separate thread
//        new HttpAsyncTask().execute("http://hmkcode.appspot.com/rest/controller/get.json");
        new HttpAsyncTask().execute("http://192.168.0.100/api.rs.com/v1/empresa_cliente/listarVarios");

        //Estableciendo la escucha
        lista.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

        String marcado = (String) lista.getItemAtPosition(position);
        Toast.makeText(this,"Ha marcado el item "+position+" "+marcado,Toast.LENGTH_LONG).show();
    }




    protected void actualizar() {
//        Funcionan
        adaptador = new ArrayAdapter<String>(Configuracion.context, android.R.layout.simple_list_item_1,datosLista.getDatosJson());
        //adaptador = new ArrayAdapter<String>(Configuracion.context, R.layout.items,R.id.textItem2,datosLista.getDatosJson());

        //Relacionando la lista con el adaptador
        lista.setAdapter(adaptador);

        //adaptador.insert(grupo, 0);
        adaptador.notifyDataSetChanged();


//        Probando uno  personalizado
//        ArrayList dato1,dato2,dato3;
//        dato1 = new ArrayList();
//        dato2 = new ArrayList();
//        dato3 = new ArrayList();
//
//        for (int  i = 0 ; i < dato1.size();i++){
//            Empresa empresa = new Empresa();
//            empresa.nombre = (String) dato1.get(i);
//            empresa.telefono = (String) dato2.get(i);
//            empresa.correo = (String) dato3.get(i);
//            empresasArrayList.add(empresa);
//        }
//
//        MiAdaptador adapter =
//                new MiAdaptador(this,empresasArrayList);
//        lista.setAdapter(adapter);
//
//        //adaptador.insert(grupo, 0);
//          adapter.notifyDataSetChanged();

    }

    public static String POST(String url) {
        InputStream inputStream = null;
        String result = "";
        try {

            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpPost(url));

            // receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();

            // convert inputstream to string
            if (inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        return result;
    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while ((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }

    public boolean isConnected() {
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(Activity.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }


    private class HttpAsyncTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... urls)            {

            return POST(urls[0]);
        }

        // onPostExecute displays the results of the AsyncTask.
        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getBaseContext(), "Received!", Toast.LENGTH_LONG).show();
            try {
                JSONObject json = new JSONObject(result);
                Log.v("RESULT",result);

                    datos= new ArrayList();
//                ArrayList dato1 = new ArrayList();
//                ArrayList dato2 = new ArrayList();
//                ArrayList dato3 = new ArrayList();

                String str = "";

                JSONArray articles = json.getJSONArray("usuario");
                str += "articles length = " + json.getJSONArray("usuario").length();
                str += "\n--------\n";
                str += "names: " + articles.getJSONObject(0).names();
                str += "\n--------\n";

                for (int i = 0 ; i < json.getJSONArray("usuario").length(); i++){

//                    Empresa empresa =new Empresa();

                    str += "is : " + articles.getJSONObject(i).getString("empresa_id");
                    str += "  noombre: " + articles.getJSONObject(i).getString("nombre");
                    str += "  telefono: " + articles.getJSONObject(i).getString("telefono");
                    str += "  correo: " + articles.getJSONObject(i).getString("correo");
                    str += "  status: " + articles.getJSONObject(i).getString("status");
                    datos.add(articles.getJSONObject(i).getString("nombre"));
//                    dato1.add(articles.getJSONObject(i).getString("nombre"));
//                    dato2.add(articles.getJSONObject(i).getString("telefono"));
//                    dato3.add(articles.getJSONObject(i).getString("correo"));
                }
//                datosLista.setDatoUno(dato1);
//                datosLista.setDatoDos(dato2);
//                datosLista.setDatoTres(dato3);
                datosLista.setDatosJson(datos);

                etResponse.setText(str);

                Log.v("PARSEADO", str);
                //etResponse.setText(json.toString(1));

                actualizar();
            } catch (JSONException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
    }




    //Adaptador
/*
    class MiAdaptador extends BaseAdapter {

        ArrayList<Empresa> empresaArrayList;
        LayoutInflater llnflater;

        MiAdaptador(Context context, ArrayList<Empresa> grupos) {
            empresaArrayList = grupos;
            llnflater = LayoutInflater.from(context);
        }


        @Override
        public int getCount() {
            return empresaArrayList.size();
        }

        @Override
        public Object getItem(int position) {
            return empresaArrayList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View view, ViewGroup parent) {

// infla el layout de cada ítem
            view = llnflater.inflate(R.layout.fila, null);
// referencia a los TextView
            TextView tvNombre = (TextView)
                    view.findViewById(R.id.textViewl);
            TextView tvMiembros = (TextView)
                    view.findViewById(R.id.textView2);
            TextView tvYears = (TextView)
                    view.findViewById(R.id.textView3);
            tvNombre.setText(empresaArrayList.get(position).nombre);
            tvMiembros.setText(empresaArrayList.get(position).telefono);
            tvYears.setText(empresaArrayList.get(position).correo);
            return view;ob
        }
    }

    class Empresa {
        String nombre;
        String telefono;
        String correo;
    }
    */
}