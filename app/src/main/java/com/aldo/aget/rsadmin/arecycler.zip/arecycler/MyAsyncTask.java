package com.aldo.aget.rsadmin.arecycler;

/**
 * Created by Work on 22/05/16.
 */
import java.io.IOException;
import org.apache.http.client.ClientProtocolException;
import org.json.JSONException;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.support.design.widget.Snackbar;
import android.view.View;
import android.widget.TextView;

public class MyAsyncTask extends AsyncTask<String,Void,String>{

    private ProgressDialog progressDialog;
    private Context context;
    TextView textView;
    View view;

    /**Constructor de clase */
    public MyAsyncTask(Context context, TextView textView, View view) {
        this.context = context;
        this.textView = textView;
        this.view = view;
    }
    /**
     * Realiza la tarea en segundo plano
     * @param params[0] Comando GET/POST
     * @param params[1] Nombre
     * @param params[2] Edad
     * */
    @Override
    protected String doInBackground(String... params) {

        if( (params[1].length()==0 || params[2].length()==0) )
        {
            return "Todos los campos son obligatorios";
        }
        else
        {
            MyRestFulGP myRestFulGP = new MyRestFulGP();
            try {
                if( params[0].equals("GET"))
                {
                    return myRestFulGP.addEventGet(params[1],params[2]);
                }else if( params[0].equals("POST"))
                {
                    return myRestFulGP.addEventPost(params[1],params[2]);
                }
            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return "";
    }

    /**
     * Antes de comenzar la tarea muestra el progressDialog
     * */
    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        progressDialog = ProgressDialog.show(
                context, "Por favor espere", "Procesando...");
    }

    /**
     * Cuando se termina de ejecutar, cierra el progressDialog y retorna el resultado a la interfaz
     * **/
    @Override
    protected void onPostExecute(String resul) {
        progressDialog.dismiss();
        textView.setText(resul);

        Snackbar.make(view, resul, Snackbar.LENGTH_LONG)
                .setAction("Action", null).show();
    }
}
