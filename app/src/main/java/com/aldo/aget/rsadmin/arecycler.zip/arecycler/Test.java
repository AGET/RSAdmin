package com.aldo.aget.rsadmin.arecycler;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;

import com.aldo.aget.rsadmin.R;

public class Test extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        FloatingActionButton fabmain = (FloatingActionButton) findViewById(R.id.fabmain);
        fabmain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, " OBR", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                obtener();
            }
        });
        FloatingActionButton fab2 = (FloatingActionButton) findViewById(R.id.fab2);
        fab2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();

                enviar();
            }
        });
    }

    void enviar(){
        Intent obt =  new Intent(this, Enviar.class);
        startActivity(obt);
    }


    void obtener(){
        Intent obt =  new Intent(this, Obtener.class);
        startActivity(obt);
    }

}
