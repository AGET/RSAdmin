package com.aldo.aget.rsadmin.arecycler;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.aldo.aget.rsadmin.R;

public class Enviar extends AppCompatActivity {

    Button btnGet;
    Button btnPost;
    EditText txtName;
    EditText txtAge;
    TextView txtResponse;

    String mensaje="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_enviar);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });




        btnGet = (Button) findViewById( R.id.btnGet );
        btnPost = (Button) findViewById( R.id.btnPost );
        txtName = (EditText) findViewById( R.id.txtName );
        txtAge = (EditText) findViewById( R.id.txtAge );
        txtResponse = (TextView) findViewById( R.id.txtResponse );
        //Evento para el boton GET
        btnGet.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new MyAsyncTask(Enviar.this, txtResponse,view)
                        .execute("GET", txtName.getText().toString(), txtAge.getText().toString());
            }
        });
        //Evento para el boton POST
        btnPost.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new MyAsyncTask(Enviar.this, txtResponse, view)
                        .execute("POST", txtName.getText().toString(), txtAge.getText().toString());
            }
        });
    }

//    void setMensajeString (String msn){
//        this.mensaje = msn;
//    }
//
//    void lanzarmensaje(){
//        Snackbar.make(findViewById(R.id.main), "Replace with your own action", Snackbar.LENGTH_LONG)
//                .setAction("Action", null).show();
//    }

}
